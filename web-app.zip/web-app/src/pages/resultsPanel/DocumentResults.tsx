import React, { useState } from "react";
import Kendra from "aws-sdk/clients/kendra";
import DynamoDB from "aws-sdk/clients/dynamodb"
import { AnimatePresence } from 'framer-motion';

import { isNullOrUndefined, selectMostRecentUpdatedTimestamp } from "../utils";

import ResultTitle from "./components/ResultTitle";
import ResultText from "./components/ResultText";
import ResultFooter from "./components/ResultFooter";
import "../search.scss";
import { Relevance } from "../constants";
import ReactPlayer from 'react-player';
import { Link } from "react-router-dom";

import PopUpBox from "../../common/PopUpBox";


interface DocumentResultsProps {
  results: Kendra.QueryResultItemList;

  submitFeedback: (
    relevance: Relevance,
    resultItem: Kendra.QueryResultItem
  ) => Promise<void>;

  dynamodb?: DynamoDB;
}

interface ToggleState {
  open: boolean;
  url: string;
  rowData: object
}

interface RenderingProps {
  result: Kendra.QueryResultItem,
  props: any
}

// function Rendering(result: Kendra.QueryResultItem, props: any) {
const RenderResult: React.FunctionComponent<RenderingProps> = ({result, props}) => {

  const [isOpen, setIsOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [originUrl, setOriginUrl] = useState("")

  const { submitFeedback, dynamodb } = props;

  let attributes = Object();
  if (!isNullOrUndefined(result.DocumentAttributes)) {
    result.DocumentAttributes!.forEach((attribute: { Key: string | number; Value: any; }) => {
      attributes[attribute.Key] = attribute.Value;
    });
  }

  const lastUpdated = selectMostRecentUpdatedTimestamp(attributes);
  let documentFile = result.DocumentURI!.split('?');
  let videoFile = ( documentFile[0]!.toUpperCase().endsWith("MP4") ||
                    documentFile[0]!.toUpperCase().endsWith("OGX") ||
                    documentFile[0]!.toUpperCase().endsWith("WEBM") ||
                    documentFile[0]!.toUpperCase().endsWith("OGV") );
  let audioFile = ( documentFile[0]!.toUpperCase().endsWith("MP3") ||
                    documentFile[0]!.toUpperCase().endsWith("WAV") ||
                    documentFile[0]!.toUpperCase().endsWith("FLAC") ||
                    documentFile[0]!.toUpperCase().endsWith("AMR") ||
                    documentFile[0]!.toUpperCase().endsWith("3GA") ||
                    documentFile[0]!.toUpperCase().endsWith("OGA") ||
                    documentFile[0]!.toUpperCase().endsWith("OGG") ||
                    documentFile[0]!.toUpperCase().endsWith("SPX") );

  const toggleOpenClose = () => {
    setIsOpen(!isOpen);
  }

  const getRowData = async (documentId: any, publishedDate: any) => {
    // format publish date returned from dynamodb
    const checkPublishDate = publishedDate + "";
    if (checkPublishDate.includes("Z")) {
        publishedDate = checkPublishDate.replace("Z", "+00:00")
    }

    // dynamodb query params
    const dbParams = {
        TableName: 'AllieDiagrams',
        Key: {
            OriginURL: {
                S: documentId
            },
            PublishDate: {
                S: publishedDate
            }
        },
    };

    dynamodb?.getItem(dbParams, (err: any, data: any) =>{
        // setOriginUrl(data.Items[0].OriginURL.S)
        // setPublishedDate(data.Items[0].PublishDate.S)
        setTitle(data.Item.Title.S)
        setOriginUrl(data.Item.OriginURL.S)
    });
  }

  getRowData(result.DocumentId, result.DocumentAttributes![0].Value.StringValue);

  return (
    <>
    <div className="container-body" key={result.Id} onClick={toggleOpenClose}>
      {/* <ResultTitle
        queryResultItem={result}
        attributes={attributes}
        submitFeedback={submitFeedback}
      /> */}
      {/* <AnimatePresence>
        {isOpen &&
          <PopUpBox
            toggleOpenClose={toggleOpenClose}
            documentUri={result.DocumentURI}
            dynamodb={dynamodb}
            documentData={result}
          />
        }
      </AnimatePresence> */}

      <img src={result.DocumentURI} style={{maxHeight: "100%", maxWidth:"100%"}} />

      <span className="truncate search-title">{title}</span><br/>
      <span className="truncate search-origin-url">{originUrl}</span>

      {/* <ResultFooter
        queryResultItem={result}
        attributes={attributes}
        submitFeedback={submitFeedback}
      /> */}
    </div>
    <AnimatePresence>
      {isOpen &&
        <PopUpBox
          toggleOpenClose={toggleOpenClose}
          documentUri={result.DocumentURI}
          dynamodb={dynamodb}
          documentData={result}
        />
      }
    </AnimatePresence>
  </>
  );

}

export default class DocumentResults extends React.Component<
  DocumentResultsProps,
  ToggleState,
  {}
> {

  /****************** OLD CODE ************************/

  // constructor(props: DocumentResultsProps) {
  //   super(props);

  //   this.state = {
  //     open: false,
  //     url: "",
  //     rowData: {}
  //   }
  // }

  // // All results in this component has QueryResultType === "ANSWER"
  // private renderResults = (result: Kendra.QueryResultItem) => {

  //   const { submitFeedback, dynamodb } = this.props;


  //   const toggleOpenClose = () => {
  //     if (this.state.open) {
  //       this.setState({open: false});
  //       this.setState({url:""})
  //       this.setState({rowData:{}})
  //     }
  //     else {
  //       this.setState({open: true});
  //       this.setState({url:result.DocumentURI!});
  //       getRowData(result.DocumentURI);
  //     }
  //   }

  //   const getRowData = (documentUri: any) => {
  //     console.log(documentUri)
  //     const dbParams = {
  //         TableName: 'AllieDiagrams',
  //         ExpressionAttributeValues: {
  //             ':architectureUrl': {
  //                 S: documentUri
  //             }
  //         },
  //         FilterExpression: 'ArchitectureURL = :architectureUrl',
  //     };

  //     dynamodb?.scan(dbParams, (err: any, data: any) =>{
  //         this.setState({rowData: data.Items[0]});
  //         console.log(this.state.rowData);
  //     });
  //   }

  //   let attributes = Object();
  //   if (!isNullOrUndefined(result.DocumentAttributes)) {
  //     result.DocumentAttributes!.forEach(attribute => {
  //       attributes[attribute.Key] = attribute.Value;
  //     });
  //   }

  //   const lastUpdated = selectMostRecentUpdatedTimestamp(attributes);
  //   let documentFile = result.DocumentURI!.split('?');
  //   let videoFile = ( documentFile[0]!.toUpperCase().endsWith("MP4") ||
  //                     documentFile[0]!.toUpperCase().endsWith("OGX") ||
  //                     documentFile[0]!.toUpperCase().endsWith("WEBM") ||
  //                     documentFile[0]!.toUpperCase().endsWith("OGV") );
  //   let audioFile = ( documentFile[0]!.toUpperCase().endsWith("MP3") ||
  //                     documentFile[0]!.toUpperCase().endsWith("WAV") ||
  //                     documentFile[0]!.toUpperCase().endsWith("FLAC") ||
  //                     documentFile[0]!.toUpperCase().endsWith("AMR") ||
  //                     documentFile[0]!.toUpperCase().endsWith("3GA") ||
  //                     documentFile[0]!.toUpperCase().endsWith("OGA") ||
  //                     documentFile[0]!.toUpperCase().endsWith("OGG") ||
  //                     documentFile[0]!.toUpperCase().endsWith("SPX") );

  //   return (
  //     <div className="container-body" key={result.Id}>
  //       {/* <ResultTitle
  //         queryResultItem={result}
  //         attributes={attributes}
  //         submitFeedback={submitFeedback}
  //       /> */}

  //       {this.state.open && 
  //         <PopUpBox
  //           toggleOpenClose={toggleOpenClose}
  //           documentUri={this.state.url}
  //           dynamodb={dynamodb}
  //         />
  //       }

  //       <img src={result.DocumentURI} style={{maxHeight: "100%", maxWidth:"100%"}} onClick={toggleOpenClose}/>

  //       {/* <ResultText
  //         className="small-margin-bottom"
  //         text={result.DocumentExcerpt!}
  //         lastUpdated={lastUpdated}
  //       />
  //        {audioFile && (
  //         <div>
  //           <audio src={result.DocumentURI} controls />
  //         </div>
  //       )}
  //       {videoFile && (
  //         <div>
  //           <ReactPlayer url={result.DocumentURI} controls={true} width='30%' height='30%' pip={true} />
  //         </div>
  //       )} */}
  //       <ResultFooter
  //         queryResultItem={result}
  //         attributes={attributes}
  //         submitFeedback={submitFeedback}
  //       />
  //     </div>
  //   );
  // };
  /*******************************************************/

  render() {
    const { results } = this.props;

    if (isNullOrUndefined(results) || results.length === 0) {
      return null;
    }

    return (
      <div className="document-results-section">
        {/* {results.map(this.renderResults)} */}
        
        {/* {results.map((result, index) => {
          return <RenderResult result={result} props={this.props}/>
        })} */}

        <div className="results-wrapper">
          {results.map((result, index) => {
            return <RenderResult result={result} props={this.props}/>
          })}
        </div>
        
      </div>
    );
  }
}
