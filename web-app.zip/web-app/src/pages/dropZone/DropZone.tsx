import { useDropzone } from "react-dropzone";

const dropzone = {
  flex: "1",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  padding: "20px",
  borderWidth: "2px",
  borderRadius: "2px",
  borderColor: "#eeeeee",
  borderStyle: "dashed",
  backgroundColor: "#fafafa",
  color: "#bdbdbd",
  outline: "none",
  transition: "border .24s ease-in-out",
};

function DropZone(props: any) {
  const { acceptedFiles, getRootProps, getInputProps } = useDropzone({
    maxFiles: 1,
    accept: {
      "image/png": [".png", ".jpeg", ".jpg"],
    },
  });
  const { getImageFile } = props;

  const files = acceptedFiles.map((file: any) => {
    // console.log(file);
    getImageFile(file);
    return (
      <li key={file.path}>
        {file.path} - {file.size} bytes
      </li>
    );
  });

  //   useEffect(() => {
  //     getImageBase64(files[0]);
  //   }, [files]);

  return (
    <>
      <div
        {...getRootProps({})}
        style={{
          height: "20em",
          flex: "1",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: "20px",
          borderWidth: "2px",
          borderRadius: "2px",
          borderColor: "#eeeeee",
          borderStyle: "dashed",
          backgroundColor: "#fafafa",
          color: "#bdbdbd",
          outline: "none",
          transition: "border .24s ease-in-out",
        }}
      >
        <input {...getInputProps()} />
        <p style={{ marginTop: "auto", marginBottom: "auto" }}>
          Drag 'n' drop an architecture diagram to start labelling <br />
          (only .png, .jpeg & .jpg accepted)
        </p>
      </div>
      <aside>
        {/* <h4>Files</h4>
        <ul>{files}</ul> */}
      </aside>
    </>
  );
}

export default DropZone;
