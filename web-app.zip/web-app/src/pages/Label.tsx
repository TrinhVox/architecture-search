import Kendra, { QueryRequest } from "aws-sdk/clients/kendra";
import { AWSError } from "aws-sdk/global";
import "bootstrap/dist/css/bootstrap.min.css";
import React, { ChangeEvent } from "react";
import { Spinner, Button } from "react-bootstrap";
import { AvailableFacetManager } from "./facets/AvailableFacetManager";
import { Facets } from "./facets/Facets";
import { SelectedFacetManager } from "./facets/SelectedFacetManager";
import {
  DataSourceNameLookup,
  getAttributeTypeLookup,
  getDataSourceNameLookup,
  IndexFieldNameToDocumentAttributeValueType,
} from "./facets/utils";
import "./search.scss";
import _ from "lodash";
import { AvailableSortingAttributesManager } from "./sorting/AvailableSortingAttributesManager";
import { SelectedSortingAttributeManager } from "./sorting/SelectedSortingAttributeManager";
import { DEFAULT_SORT_ATTRIBUTE, SortOrderEnum } from "./sorting/constants";
import S3 from "aws-sdk/clients/s3";
import DynamoDB from "aws-sdk/clients/dynamodb";
import ImageLabel from "./imageLabel/ImageLabel";
import DropZone from "./dropZone/DropZone";
import ReferenceLinks from "./referenceLinks/ReferenceLinks";
import axios from "axios";

var fs = require("fs");
var API_ENDPOINT = "api endpoint with path to label";

interface LabelProps {
  /* An authenticated instance of the Kendra SDK */
  kendra?: Kendra;
  /* The ID of an index in the account the Kendra SDK is authenticated for */
  indexId: string;

  s3?: S3;
  accessToken?: string;

  dynamodb?: DynamoDB;

  facetConfiguration?: {
    facetsToShowWhenUncollapsed: number;
    showCount: boolean;
    updateAvailableFacetsWhenFilterChange: boolean;
    facetPanelDefaultOpen: boolean;
  };
}

interface LabelState {
  dataReady: boolean;
  preview: File | null;
  previewUrl: string;
  response: any;
  referenceLinks: Array<any>;
  searchResults: Kendra.QueryResult;
  topResults: Kendra.QueryResultItemList;
  faqResults: Kendra.QueryResultItemList;
  docResults: Kendra.QueryResultItemList;
  currentPageNumber: number;
  queryText: string;
  error?: AWSError;
  index?: Kendra.DescribeIndexResponse;
  facetsOpen: boolean;

  // Faceting state
  attributeTypeLookup?: IndexFieldNameToDocumentAttributeValueType;
  availableFacets: AvailableFacetManager;
  dataSourceNameLookup?: DataSourceNameLookup;
  selectedFacets: SelectedFacetManager;

  // Sorting state
  availableSortingAttributes: AvailableSortingAttributesManager;
  selectedSortingAttribute: SelectedSortingAttributeManager;
}

export default class Label extends React.Component<LabelProps, LabelState> {
  constructor(props: LabelProps) {
    super(props);

    this.state = {
      dataReady: true,
      preview: null,
      previewUrl: "",
      response: null,
      referenceLinks: [],
      searchResults: {},
      topResults: [],
      faqResults: [],
      docResults: [],
      currentPageNumber: 1,
      queryText: "",
      error: undefined,
      attributeTypeLookup: undefined,
      availableFacets: AvailableFacetManager.empty(),
      selectedFacets: SelectedFacetManager.empty(),
      index: undefined,
      facetsOpen:
        (this.props.facetConfiguration &&
          this.props.facetConfiguration.facetPanelDefaultOpen) ??
        false,
      availableSortingAttributes: AvailableSortingAttributesManager.empty(),
      selectedSortingAttribute: SelectedSortingAttributeManager.default(),
    };
  }

  private getErrorNotification = () => {
    return (
      <div className="error-div">
        {!_.isEmpty(this.state.error?.message)
          ? this.state.error?.message
          : this.state.error?.code}
      </div>
    );
  };

  getImageFile = (file: File) => {
    // console.log("File: ", file);
    if (file) {
      this.setState({
        ...this.state,
        preview: file,
        previewUrl: URL.createObjectURL(file),
      });
    }
  };

  uploadImage = async () => {
    this.setState({ ...this.state, dataReady: false });
    var reader = new FileReader();
    // console.log(this.state.preview);
    if (this.state.preview) {
      reader.readAsDataURL(this.state.preview);
      reader.onload = async () => {
        // console.log(reader.result);
        console.log("Upload triggered");
        axios
          .post(
            API_ENDPOINT,
            {
              byte: reader.result,
            },
            {
              // headers: {
              //   "Access-Control-Allow-Origin": "*",
              // },
            }
          )
          .then((response) => {
            // console.log(response);
            this.setState({
              ...this.state,
              response: response?.data,
              referenceLinks: response?.data.ref_links,
            });
          })
          .finally(() => {
            this.setState({ ...this.state, preview: null, dataReady: true });
          });
      };
      reader.onerror = async (error) => {
        console.log("Error: ", error);
      };
    }
  };

  render() {
    return (
      <div>
        <div style={{ textAlign: "center", marginTop: "2em" }}>
          <h4>Amazon Allie Labelling Service</h4>
          {this.state.preview == null && this.state.response == null ? (
            <div
              style={{
                maxWidth: "50em",
                marginLeft: "auto",
                marginRight: "auto",
              }}
            >
              <p style={{ marginBottom: "1em" }}>
                Start by dropping an architecture diagram to idenfy the services
                and retrieve the documentation links.
              </p>
              <DropZone getImageFile={this.getImageFile} />
            </div>
          ) : (
            ""
          )}
          {this.state.preview ? (
            <>
              <div>
                <p style={{ marginBottom: "1em" }}>
                  Is this the diagram you want to upload? If so hit
                  <b> Upload</b>! <br />
                  Otherwise, click <b>Re-select Image</b> to select another
                  image.
                </p>
              </div>
              <div>
                <Button
                  style={{ marginLeft: "1em", marginRight: "1em" }}
                  onClick={() =>
                    this.setState({ ...this.state, preview: null })
                  }
                  disabled={!this.state.dataReady}
                >
                  Re-select Image
                </Button>
                <Button
                  style={{ marginLeft: "1em", marginRight: "1em" }}
                  onClick={() => this.uploadImage()}
                  disabled={!this.state.dataReady}
                >
                  Upload{" "}
                  {!this.state.dataReady ? (
                    <Spinner
                      as="span"
                      animation="border"
                      size="sm"
                      role="status"
                      aria-hidden="true"
                    />
                  ) : (
                    ""
                  )}
                </Button>
              </div>
              <img
                src={this.state.previewUrl}
                alt="Image Preview"
                style={{
                  maxWidth: "50em",
                  marginLeft: "auto",
                  marginRight: "auto",
                  marginTop: "2em",
                }}
              />
            </>
          ) : (
            ""
          )}
          {this.state.dataReady && this.state.response ? (
            <>
              <div>
                <p style={{ marginBottom: "1em" }}>
                  Alright! We managed to identify a couple of services. Hover
                  over them to see what they are. <br /> We also gathered a list
                  of documentation links down below.
                </p>
              </div>
              <div>
                <Button
                  style={{ marginLeft: "1em", marginRight: "1em" }}
                  onClick={() =>
                    this.setState({ ...this.state, response: null })
                  }
                >
                  Re-select Image
                </Button>
              </div>
              <ImageLabel
                path={this.state.previewUrl}
                response={this.state.response}
              />
              <h4>Reference Links</h4>
              <ReferenceLinks links={this.state.referenceLinks} />
            </>
          ) : (
            ""
          )}
        </div>
        {this.state.error && this.getErrorNotification()}
      </div>
    );
  }
}
