import { useEffect } from "react";
// var htmlToRtf = require('html-to-rtf');

function ReferenceLinks(props: any) {
  const { links } = props;
  // const [clipboard, setClipboard] = useState("")
  // var clipboard = ""

  const generateLinks = () => {
    // console.log(links)
    return links.map((link: any) => {
      return (
        <li key={link.Service}>
          <div>
            {link.Service.replaceAll("-", " ")}:{" "}
            <a href={link.Link} target="_blank" rel="noreferrer">
              {link.Link}
            </a>
          </div>
        </li>
      );
    });
  };

  //   const copyToClipboard = () => {navigator.clipboard.writeText(clipboard)}

  useEffect(() => {
    // console.log("Links: ", links);
  }, []);

  return (
    <div
      style={{
        maxWidth: "50em",
        marginLeft: "auto",
        marginRight: "auto",
        textAlign: "left",
      }}
    >
      <ul>{generateLinks()}</ul>
      {/* <Button onClick={() => copyToClipboard()}>Copy to Clipboard</Button> */}
    </div>
  );
}

export default ReferenceLinks;
