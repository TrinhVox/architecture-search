import React from "react";
import { Row } from "react-bootstrap";
import * as ReactDOM from "react-dom";

interface ImageLabelProps {
  path: string;
}

interface ImageLabelState {
  rects: Array<any>;
}

export default class ImageLabel extends React.Component<
  ImageLabelProps,
  ImageLabelState
> {
  constructor(props: ImageLabelProps) {
    super(props);
    this.state = {
      rects: [
        [110, 30, 70, 70],
        [40, 30, 70, 70],
      ],
    };
    // this.tagPerson = this.tagPerson.bind(this);
  }
  //   tagPerson(e) {
  //     var x = e.offsetX,
  //       y = e.offsetY;
  //     for (var i = 0; i < this.props.rects.length; i++) {
  //       // check whether:
  //       if (
  //         x > this.props.rects[i][0] && // mouse x between x and x + width
  //         x < this.props.rects[i][0] + this.props.rects[i][2] &&
  //         y > this.props.rects[i][1] && // mouse y between y and y + height
  //         y < this.props.rects[i][1] + this.props.rects[i][3]
  //       ) {
  //         alert("Rectangle " + i + " clicked");
  //       }
  //     }
  //   }
  drawRects() {
    let canvas = ReactDOM.findDOMNode(this.refs.imgCanvas) as HTMLCanvasElement;
//     canvas.setAttribute('height', style_height * dpi);
// canvas.setAttribute('width', style_width * dpi);
    let ctx = canvas?.getContext("2d");
    if (ctx != null) {
    //   ctx.imageSmoothingEnabled = false;
      var img = new Image();
      img.src = this.props.path;
      var hRatio = canvas.width / img.width;
      var vRatio = canvas.height / img.height;
      var ratio = Math.min(hRatio, vRatio);
      var centerShift_x = (canvas.width - img.width * ratio) / 2;
      var centerShift_y = (canvas.height - img.height * ratio) / 2;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(
        img,
        0,
        0,
        img.width,
        img.height,
        centerShift_x,
        centerShift_y,
        img.width * ratio,
        img.height * ratio
      );
      ctx.beginPath();
      ctx.strokeStyle = "red";
      for (var i = 0; i < this.state.rects.length; i++) {
        ctx.rect(
          this.state.rects[i][0], // fill at (x, y) with (width, height)
          this.state.rects[i][1],
          this.state.rects[i][2],
          this.state.rects[i][3]
        );
        // ctx.rect();
        console.log("helloo");
      }
      console.log(this.state.rects);
      ctx.stroke();
    }
  }
  componentDidMount() {
    console.log("componentDidMount");
    var img = new Image();
    img.onload = this.drawRects.bind(this);

    img.src = this.props.path;
  }
  render() {
    this.drawRects();
    return (
      <>
        <div style={{ textAlign: "center", marginTop: "2em" }}>
          <div className="container-body">
            <canvas ref="imgCanvas" style={{ width: "40em" }} />
          </div>
        </div>
      </>
    );
  }
}
