import React from "react";
// import mocks from "./mocks";
// import response from "./response";
import Annotation from "../../lib/react-image-annotation";
import { RectangleSelector } from "../../lib/react-image-annotation/selectors";

interface ImageLabelProps {
  path: string;
  response: any;
}

interface ImageLabelState {
  annotations: Array<any>;
  annotation: any;
  type: HTMLInputElement | null;
}

const Box = ({ children, geometry, style }: any) => (
  <div
    style={{
      ...style,
      position: "absolute",
      left: `${geometry.x}%`,
      top: `${geometry.y}%`,
      height: `${geometry.height}%`,
      width: `${geometry.width}%`,
    }}
  >
    {children}
  </div>
);

function renderHighlight({ annotation, active }: any) {
  const { geometry } = annotation;
  if (!geometry) return null;

  return (
    <Box
      key={annotation.data.id}
      geometry={geometry}
      style={{
        border: "solid 1px black",
        boxShadow: active && "0 0 20px 20px rgba(255, 255, 255, 0.3) inset",
      }}
    ></Box>
  );
}

function renderContent({ annotation }: any) {
  const { geometry } = annotation;

  return (
    <>
      <div
        key={annotation.data.id}
        style={{
          background: "black",
          color: "white",
          padding: 10,
          position: "absolute",
          fontSize: 12,
          left: `${geometry.x}%`,
          top: `${geometry.y + geometry.height}%`,
        }}
      >
        {annotation.data && annotation.data.text}<br/>
        Confidence: {annotation.data && Math.round(annotation.data.confidence)}%
      </div>
    </>
  );
}

function renderOverlay() {
  return <></>;
}

export default class ImageLabel extends React.Component<
  ImageLabelProps,
  ImageLabelState
> {
  constructor(props: ImageLabelProps) {
    super(props);
    this.state = {
      annotations: [],
      annotation: {},
      type: null,
    };
  }

  setAnnotations(response: any) {
    // console.log("Response: ", response);
    var count = 0;
    var _annotations: Array<any> = [];
    response?.labels.map((label: any) => {
      // console.log(label);
      var left = label.Geometry.BoundingBox.Left * 100;
      var top = label.Geometry.BoundingBox.Top * 100;
      var width = label.Geometry.BoundingBox.Width * 100;
      var height = label.Geometry.BoundingBox.Height * 100;
      var pass = false;
      var i = _annotations.length;
      while (i > 0 && i--) {
        var item = _annotations[i];
        if (
          Math.abs(left - item.geometry.x) <
            Math.max(width, item.geometry.width) &&
          Math.abs(top - item.geometry.y) <
            Math.max(height, item.geometry.height)
        ) {
          if (item.data.confidence > label.Confidence) {
            pass = true;
          } else {
            _annotations.splice(i, 1);
            break;
          }
        }
      }
      if (!pass) {
        count += 1;
        _annotations.push({
          key: count,
          geometry: {
            type: RectangleSelector.TYPE,
            x: left,
            y: top,
            width: width,
            height: height,
          },
          data: {
            text: label.Name,
            confidence: label.Confidence,
            id: count,
          },
        });
      }
      return;
    });
    // console.log("Annotations: ", _annotations);
    this.setState({ annotations: _annotations });
  }

  componentDidMount() {
    this.setAnnotations(this.props.response);
  }

  render() {
    return (
      <div style={{ marginTop: "2em" }}>
        <Annotation
          style={{
            maxWidth: "50em",
            marginLeft: "auto",
            marginRight: "auto",
            marginBottom: "5em",
          }}
          src={this.props.path}
          annotations={this.state.annotations}
          value={this.state.annotation}
          renderHighlight={renderHighlight}
          renderContent={renderContent}
          renderOverlay={renderOverlay}
        />
      </div>
    );
  }
}
