import React, { useEffect, useState, Component } from 'react';
import DynamoDB from "aws-sdk/clients/dynamodb";
import { getDataSourceNameLookup } from '../pages/facets/utils';
import { motion } from 'framer-motion';
import { FaTimes } from "react-icons/fa"

interface PopUpBoxProps {
    toggleOpenClose: any;
    documentUri: any;
    dynamodb?: DynamoDB;
    documentData: any;
}

const PopUpBox: React.FunctionComponent<PopUpBoxProps> = ({toggleOpenClose, documentUri, dynamodb, documentData}) => {
    const [originUrl, setOriginUrl] = useState("")
    const [publishedDate, setPublishedDate] = useState("")
    const [title, setTitle] = useState("")
    const [referenceLinks, setReferenceLinks] = useState([] as any)

    
    // const getRowData = async (documentUri: any) => {
    //     const dbParams = {
    //         TableName: 'AllieDiagrams',
    //         ExpressionAttributeValues: {
    //             ':architectureUrl': {
    //                 S: documentUri
    //             }
    //         },
    //         FilterExpression: 'ArchitectureURL = :architectureUrl',
    //     };

    //     dynamodb?.scan(dbParams, (err: any, data: any) =>{
    //         setOriginUrl(data.Items[0].OriginURL.S)
    //         setPublishedDate(data.Items[0].PublishDate.S)
    //     });
    // }

    // getRowData(documentUri);

    const getRowData = async (documentId: any, publishedDate: any) => {
        // format publish date returned from dynamodb
        const checkPublishDate = publishedDate + "";
        if (checkPublishDate.includes("Z")) {
            publishedDate = checkPublishDate.replace("Z", "+00:00")
        }

        // dynamodb query params
        const dbParams = {
            TableName: 'AllieDiagrams',
            Key: {
                OriginURL: {
                    S: documentId
                },
                PublishDate: {
                    S: publishedDate
                }
            },
        };

        dynamodb?.getItem(dbParams, (err: any, data: any) =>{
            setTitle(data.Item.Title.S);
            setOriginUrl(data.Item.OriginURL.S);
            // console.log(new Date(data.Item.PublishDate.S).toLocaleDateString());
            setPublishedDate(new Date(data.Item.PublishDate.S).toLocaleDateString());
            // console.log(data.Item.Reference.L)
            setReferenceLinks(data.Item.Reference.L)
            // data.Item.Reference.L.map((result: any, index: any) => {
            //     setReferenceLinks((arr: any)  => [...arr, result])
            // })
            
        });
    }

    useEffect(() => {
        // 👇️ only runs once
        console.log('useEffect ran');
        getRowData(documentData.DocumentId, documentData.DocumentAttributes[0].Value.StringValue);
      }, []);

    return (
        <motion.div
            initial={{
                opacity: 0
            }}
            animate={{
                opacity: 1,
                transition: {
                    duration: 0.3
                }
            }}
            exit={{
                opacity: 0,
                transition: {
                    duration: 0.3
                }
            }}
            className="popup-backdrop"
        >
            <motion.div
                initial={{
                    scale: 0
                }}
                animate={{
                    scale: 1,
                    transition: {
                        duration: 0.3
                    }
                }}
                exit={{
                    scale: 0,
                    transition: {
                        duration: 0.3
                    }
                }}
                className="popup-box"
            >
            <FaTimes className="popup-close" onClick={toggleOpenClose}/>
            <img src={documentData.DocumentURI} style={{maxHeight: "100%", maxWidth:"100%"}} />
            <h1>{title}</h1>
            <div className="popup-body">
                <div>
                    <p><strong>Published Date:</strong> {publishedDate}</p>            
                    {/* {(referenceLinks.length > 0) && 
                        referenceLinks.map((referenceLink: any) => (
                            <a href={referenceLink.M.link.S} target="_blank">{referenceLink.M.service.S}<br/></a>
                        ))
                    } */}
                    {(referenceLinks.length > 0) && 
                        referenceLinks.map((referenceLink: any) => (
                            <>
                                {referenceLink.M.service.S == referenceLinks[referenceLinks.length-1].M.service.S ? 
                                    <a href={referenceLink.M.link.S} target="_blank">{referenceLink.M.service.S}</a> :
                                    <a href={referenceLink.M.link.S} target="_blank">{referenceLink.M.service.S} | </a>
                                }
                            </>
                        ))
                    }
                </div>
                <a href={originUrl} target="_black">
                    <div className="button-popup-redirect btn-slide-line center">
                        <span>Go To Source</span>
                    </div>
                </a> 
            </div>
            {/* <a href={originUrl} target="_black">
                <div className="button-popup-redirect btn-slide-line center">
                    <span>Go To Source</span>
                </div>
            </a> */}
            {/* <p><a href={originUrl} target="_blank">{originUrl}</a></p> */}
            {/* <p><p>Published Date: </p>{publishedDate}</p>            
            {(referenceLinks.length > 0) && 
                referenceLinks.map((referenceLink: any) => (
                    <a href={referenceLink.M.link.S} target="_blank">{referenceLink.M.service.S}<br/></a>
                ))
            } */}
            
            </motion.div>
        </motion.div>
    )
}

export default PopUpBox;
