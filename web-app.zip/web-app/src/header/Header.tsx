import React from "react";
import { Container, Nav, Navbar, NavDropdown } from "react-bootstrap";

interface HeaderState {}

interface HeaderProps {}

export default class Header extends React.Component<HeaderProps, HeaderState> {
  render() {
    return (
      <Navbar bg="light" expand="lg">
        <Container>
          <Navbar.Brand href="/">Amazon Allie</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/search">Search</Nav.Link>
              <Nav.Link href="/label">Label</Nav.Link>
              {/* <NavDropdown title="About" id="basic-nav-dropdown">
                <NavDropdown.Item href="/prfaq">PR/FAQ</NavDropdown.Item>
                <NavDropdown.Item href="/documentation">
                  Documentation
                </NavDropdown.Item>
                <NavDropdown.Item href="/team">Team</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">
                  Separated link
                </NavDropdown.Item>
              </NavDropdown> */}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}
