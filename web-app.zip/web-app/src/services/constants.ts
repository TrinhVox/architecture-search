export const CREDENTIALS_FILE_NAME = "local-dev-credentials.json";
export const CREDENTIALS_FILE_PATH = "/src/services";
