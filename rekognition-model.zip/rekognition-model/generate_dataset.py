from modulefinder import replacePackageMap
from PIL import Image
import sys
import os
import boto3
from botocore.exceptions import ClientError
import logging
import csv
import json

############# Add relevant variables #############
ACCESS_KEY_ID = "Access Key ID"
SECRET_ACCESS_KEY = "Secret access key"
S3_BUCKET = "custom-labels-console bucket name"
############# Add relevant variables #############


OUTPUT_DIR = "dataset"
CSV_MANIFEST = "manifest.csv"
S3_PREFIX = "service-icons-dataset"
REKOGNITION_PROJECT_NAME = sys.argv[1]


rekognition = boto3.client(
    'rekognition',
    aws_access_key_id=ACCESS_KEY_ID,
    aws_secret_access_key=SECRET_ACCESS_KEY,
)

s3 = boto3.client(
    's3',
    aws_access_key_id=ACCESS_KEY_ID,
    aws_secret_access_key=SECRET_ACCESS_KEY,
)



def upload_to_s3():
    print("Starting upload to S3...")

    count = 0

    for filename in os.listdir(OUTPUT_DIR):
        try:
            s3.upload_file("{}/{}".format(OUTPUT_DIR, filename),
                           S3_BUCKET, "{}/{}".format(S3_PREFIX, filename))
            # print("{} uploaded".format(filename))
            count += 1
            sys.stdout.write("\rUploaded: {}".format(count))
            sys.stdout.flush()
        except ClientError as e:
            logging.error(e)

### End 2 ###

### Start 3 ###


def create_csv(dataset):
    print("Creating manifest file...")

    with open(CSV_MANIFEST, 'w', newline='') as file:
        writer = csv.writer(file)

        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=S3_BUCKET, Prefix=S3_PREFIX)

        contents = []

        for page in pages:
            for obj in page['Contents']:
                contents.append(obj)

        print("{} items".format(len(contents)))

        for obj in contents:
            if "canvas" in obj["Key"] and dataset == "TEST":
                label = extract_label(obj["Key"])
            elif dataset == "TRAINING" and "canvas" not in obj["Key"]:
                label = extract_label(obj["Key"])
                print(label)
            else:
                continue
            # print("s3://{}/{},{}".format(S3_BUCKET, obj["Key"], label))
            if label:  # swap if narrowing down services
                row = ["s3://{}/{}".format(S3_BUCKET, obj["Key"]), label]
                writer.writerow(row)
    file.close()


def extract_label(key):
    try:
        filename = key.split("/")[-1].split(".")[0]
        filename_list = filename.split("_")
        if (filename_list[0] == "Arch"):
            if (filename_list[1].split("-")[0] in ["Amazon", "AWS"] or filename_list[1] == "Elastic-Load-Balancing"):
                return filename_list[1]
        # if (filename_list[0] == "Arch" or filename_list[0] == "Arch-Category"):
        #     return filename_list[1]
        # else:
        #     if (filename_list[2].isdigit()):
        #         return filename_list[1]
        elif (filename_list[0] == "Res"):
            return "{}-{}".format(filename_list[1], filename_list[2])
    except:
        print("{} has a different file name format".format(key))

### End 3 ###

### Start 4 ###


def generate_manifest():
    os.system("python3 generate_manifest.py {} {}".format(
        CSV_MANIFEST, REKOGNITION_PROJECT_NAME))


def upload_to_training():
    print("Uploading to rekognition...")

    describe_project_res = rekognition.describe_projects(
        ProjectNames=[REKOGNITION_PROJECT_NAME]
    )
    
    project = describe_project_res["ProjectDescriptions"][0]
    projectArn = project["ProjectArn"]
    try:
        oldDatasetArn = [x["DatasetArn"]
                         for x in project["Datasets"] if x["DatasetType"] == "TRAIN"][0]
        rekognition.delete_dataset(
            DatasetArn=oldDatasetArn
        )
    except:
        pass

    # dataset ARN required: aws rekognition describe-projects
    create_data_res = rekognition.create_dataset(
        DatasetType="TRAIN",
        ProjectArn=projectArn
    )

    datasetArn = create_data_res["DatasetArn"]
    manifestfile = open("manifest.manifest").read()

    rekognition.update_dataset_entries(
        DatasetArn=datasetArn,
        Changes={
            "GroundTruth": manifestfile
        }
    )

    describe_dataset_res = rekognition.describe_dataset(
        DatasetArn=datasetArn
    )

    print("Dataset ARN: ", datasetArn)
    print("Dataset Status: ", json.dumps(
        describe_dataset_res, indent=4, sort_keys=True, default=str))


def upload_to_test():
    print("Uploading to rekognition test...")

    describe_project_res = rekognition.describe_projects(
        ProjectNames=[REKOGNITION_PROJECT_NAME]
    )

    project = describe_project_res["ProjectDescriptions"][0]
    projectArn = project["ProjectArn"]
    try:
        oldDatasetArn = [x["DatasetArn"]
                         for x in project["Datasets"] if x["DatasetType"] == "TEST"][0]
        rekognition.delete_dataset(
            DatasetArn=oldDatasetArn
        )
    except:
        pass

    # dataset ARN required: aws rekognition describe-projects
    create_data_res = rekognition.create_dataset(
        DatasetType="TEST",
        ProjectArn=projectArn
    )

    datasetArn = create_data_res["DatasetArn"]
    manifestfile = open("manifest.manifest").read()

    rekognition.update_dataset_entries(
        DatasetArn=datasetArn,
        Changes={
            "GroundTruth": manifestfile
        }
    )

    describe_dataset_res = rekognition.describe_dataset(
        DatasetArn=datasetArn
    )

    print("Dataset ARN: ", datasetArn)
    print("Dataset Status: ", json.dumps(
        describe_dataset_res, indent=4, sort_keys=True, default=str))
### End 4 ###



upload_to_s3()

create_csv("TRAINING")
generate_manifest()
upload_to_training()

create_csv("TEST")
generate_manifest()
upload_to_test()

