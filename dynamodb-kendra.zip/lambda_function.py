import json
import urllib
import boto3
import datetime
import os


s3 = boto3.client(service_name='s3')
DYNAMODB = boto3.client('dynamodb')
KENDRA = boto3.client('kendra')

INDEX_ID = os.environ['INDEX_ID']
DS_ID = os.environ['DS_ID']


def lambda_handler(event, context):
    dbRecords = event['Records']

    for r in dbRecords:
        rowData = r['dynamodb']['NewImage']
        originUrl = rowData['OriginURL']['S']
        publishedDate = rowData['PublishDate']['S']
        architectureUrl = rowData['ArchitectureURL']['S'] # to change
        title = rowData['Title']['S']
        
        metadata = rowData['Metadata']['M']
        crawlerMetadata = metadata['crawler']['S']
        rekognitionMetadata = metadata['Rekognition']['M']
        rekognitionLabels = rekognitionMetadata['labels']['S']
        rekognitionRawText = rekognitionMetadata['textMetadata']['S']
        rekognitionServices = rekognitionMetadata['textServices']['S']
        
        # print (originUrl)
        # print (publishedDate)
        # print (architectureUrl)
        # print (metadata)
        # print (crawlerMetadata)
        # print (rekognitionMetadata)
        # print (rekognitionLabels)
        # print (rekognitionRawText)
        # print (rekognitionServices)
        
        concatenatedText = f"{crawlerMetadata} {rekognitionLabels} {rekognitionServices}"

        put_document(dsId=DS_ID, indexId=INDEX_ID, originUrl=originUrl, architectureUrl=architectureUrl, title=title, publishedDate=publishedDate, text=concatenatedText)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
    
def put_document(dsId, indexId, originUrl, architectureUrl, title, publishedDate , text):
    document = get_document(dsId, indexId, originUrl, architectureUrl, title, publishedDate, text)
    documents = [document]
    result = KENDRA.batch_put_document(
        IndexId = indexId,
        Documents = documents
    )
    print ("result:" + json.dumps(result))
    return True

def get_document(dsId, indexId, originUrl, architectureUrl, title, publishedDate, text):
    document = {
        "Id": originUrl,
        "Title": title,
        "Attributes": [
            {
                "Key": "_data_source_id",
                "Value": {
                    "StringValue": dsId
                }
            },
            # {
            #     "Key": "_data_source_sync_job_execution_id",
            #     "Value": {
            #         "StringValue": item['sync_job_id']
            #     }
            # },
            {
                "Key": "_source_uri",
                "Value": {
                    "StringValue": architectureUrl
                }
            },
            {
                "Key": "_created_at",
                "Value": {
                    "DateValue": publishedDate
                }
            }
            #{
            #    "Key": "publish_date",
            #    "Value": {
            #        "DateValue": publishedDate
            #    }
            #}
        ],
        "Blob": text
    }
    
    # # merge metadata
    # metadata = get_s3jsondata(item['metadata_url'])
    # if metadata.get("DocumentId"):
    #     logger.error(f"Metadata may not override: DocumentId")
    # if metadata.get("ContentType"):
    #     logger.error(f"Metadata may not override: ContentType") 
    # if metadata.get("Title"):
    #     logger.info(f"Set 'Title' to: \"{metadata['Title']}\"")  
    #     document['Title'] = metadata['Title']
    # if metadata.get("Attributes"):
    #     logger.info(f"Set 'Attributes'")
    #     metadata_attributes = get_metadata_attributes(metadata)
    #     document["Attributes"] += metadata_attributes
    # if metadata.get("AccessControlList"):
    #     logger.info(f"Set 'AccessControlList'")
    #     document["AccessControlList"] = metadata['AccessControlList']
    return document
    
def parse_s3url(s3url):
    r = urllib.parse.urlparse(s3url, allow_fragments=False)
    bucket = r.netloc
    key = r.path.lstrip("/")
    file_name = key.split("/")[-1]
    return [bucket, key, file_name]

def get_bucket_region(bucket):
    # get bucket location.. buckets in us-east-1 return None, otherwise region is identified in LocationConstraint
    try:
        region = S3.get_bucket_location(Bucket=bucket)["LocationConstraint"] or 'ap-southeast-1' 
    except Exception as e:
        region = 'ap-southeast-1'
    return region

def get_presigned_url(bucketName, objectPath):
    # generate pre-signed url for object
    presigned_url = boto3.client('s3').generate_presigned_url(
        ClientMethod='get_object', 
        Params={'Bucket': bucketName, 'Key': objectPath},
        ExpiresIn=3600
    )
    
    print (presigned_url)
    return

def delete_document(docIds):
    KENDRA.batch_delete_document(
        IndexId=INDEX_ID,
        # DocumentIdList=[
        #     'string',
        # ],
        DocumentIdList=docIds, # array of doc ids
        DataSourceSyncJobMetricTarget={
            'DataSourceId': DS_ID
        }
    )

def get_document_status(docId):
    response = KENDRA.batch_get_document_status(
        IndexId=INDEX_ID,
        DocumentInfoList=[
            {
                'DocumentId': docId
            },
        ]
    )
        
    print (response)
